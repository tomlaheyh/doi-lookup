// content.js — DOI-Ref-Lookup Chrome Extension
// Scans the page for DOIs and injects a small "Ref" button next to each one.

(function () {
  'use strict';

  const SITE_URL = 'https://tomlaheyh.github.io/ref-lookup/';
  const BUTTON_CLASS = 'doi-ref-lookup-btn';
  const PROCESSED_ATTR = 'data-doi-ref-processed';

  // DOI pattern: 10.XXXX/... allowing parentheses within DOIs
  // Many DOIs (esp. Lancet/Elsevier) contain parens like 10.1016/S0140-6736(24)02679-5
  const DOI_REGEX = /\b(10\.\d{4,}\/[^\s<>,;'"}\]]+)/gi;
  const DOI_URL_REGEX = /https?:\/\/(?:dx\.)?doi\.org\/(10\.\d{4,}\/[^\s<>,;'"}\]]+)/gi;

  // Clean trailing punctuation and unbalanced parentheses
  function cleanDoi(doi) {
    // Strip trailing periods
    doi = doi.replace(/\.+$/, '');
    // Strip trailing ) only if unbalanced (more closing than opening)
    while (doi.endsWith(')') && (doi.split('(').length - 1) < (doi.split(')').length - 1)) {
      doi = doi.slice(0, -1);
    }
    return doi;
  }

  // Create the Ref button element
  function createRefButton(doi) {
    const btn = document.createElement('button');
    btn.className = BUTTON_CLASS;
    btn.textContent = 'Ref';
    btn.title = `Look up ${doi} in DOI-Ref-Lookup`;
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (btn.disabled) return;
      validateAndOpen(doi, btn);
    });
    return btn;
  }

  // Validate DOI exists via background script, then open
  async function validateAndOpen(doi, btn) {
    const originalText = btn.textContent;
    btn.textContent = '...';
    btn.disabled = true;
    btn.style.opacity = '0.7';

    try {
      const response = await chrome.runtime.sendMessage({
        action: 'validateAndOpenDoi',
        doi: doi
      });

      if (response && response.valid) {
        btn.textContent = '✓';
        btn.style.background = '#2a7a2a';
        setTimeout(() => {
          btn.textContent = 'Ref';
          btn.style.background = '';
          btn.disabled = false;
          btn.style.opacity = '';
        }, 1500);
      } else {
        btn.textContent = 'Not found';
        btn.style.background = '#8c2a2a';
        setTimeout(() => {
          btn.textContent = originalText;
          btn.style.background = '';
          btn.disabled = false;
          btn.style.opacity = '';
        }, 2000);
      }
    } catch (err) {
      btn.textContent = 'Error';
      btn.style.background = '#8c2a2a';
      setTimeout(() => {
        btn.textContent = originalText;
        btn.style.background = '';
        btn.disabled = false;
        btn.style.opacity = '';
      }, 2000);
    }
  }

  // Walk text nodes and find DOIs
  function scanForDois() {
    // Skip if already scanned
    if (document.body.hasAttribute(PROCESSED_ATTR)) return;

    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: function (node) {
          // Skip script, style, textarea, input, and already-processed elements
          const tag = node.parentElement?.tagName?.toUpperCase();
          if (!tag) return NodeFilter.FILTER_REJECT;
          if (['SCRIPT', 'STYLE', 'TEXTAREA', 'INPUT', 'CODE', 'PRE', 'NOSCRIPT'].includes(tag)) {
            return NodeFilter.FILTER_REJECT;
          }
          // Skip our own buttons
          if (node.parentElement.classList?.contains(BUTTON_CLASS)) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );

    const textNodes = [];
    while (walker.nextNode()) {
      textNodes.push(walker.currentNode);
    }

    // Also scan <a> elements with DOI URLs in href
    const links = document.querySelectorAll('a[href*="doi.org/10."]');

    // Track DOIs we've already buttoned to avoid duplicates in the same area
    const processedDois = new Set();

    // Process text nodes — split at DOI and insert button inline
    for (const node of textNodes) {
      const text = node.textContent;
      DOI_REGEX.lastIndex = 0;
      let match;
      const matches = [];

      while ((match = DOI_REGEX.exec(text)) !== null) {
        const doi = cleanDoi(match[1]);
        if (!processedDois.has(doi)) {
          matches.push({
            doi: doi,
            index: match.index,
            length: match[1].length
          });
        }
      }

      if (matches.length === 0) continue;

      const parent = node.parentElement;
      if (!parent || parent.hasAttribute(PROCESSED_ATTR)) continue;

      // Process matches in reverse order so indices stay valid
      let currentNode = node;
      for (let i = matches.length - 1; i >= 0; i--) {
        const m = matches[i];
        processedDois.add(m.doi);

        // Split the text node: [before DOI][DOI text][after DOI]
        const doiEnd = m.index + m.length;
        const afterNode = currentNode.splitText(doiEnd);
        const doiNode = currentNode.splitText(m.index);

        // Insert button between DOI text and the rest
        const btn = createRefButton(m.doi);
        parent.insertBefore(btn, afterNode);

        // Continue working with the part before this DOI for earlier matches
        currentNode = currentNode;
      }
      parent.setAttribute(PROCESSED_ATTR, 'true');
    }

    // Process DOI links
    for (const link of links) {
      if (link.hasAttribute(PROCESSED_ATTR)) continue;

      const href = link.href;
      DOI_URL_REGEX.lastIndex = 0;
      const match = DOI_URL_REGEX.exec(href);
      if (!match) continue;

      const doi = cleanDoi(match[1]);
      if (processedDois.has(doi)) {
        link.setAttribute(PROCESSED_ATTR, 'true');
        continue;
      }
      processedDois.add(doi);

      const btn = createRefButton(doi);
      link.parentElement?.insertBefore(btn, link.nextSibling);
      link.setAttribute(PROCESSED_ATTR, 'true');
    }

    document.body.setAttribute(PROCESSED_ATTR, 'true');
  }

  // Run on page load
  scanForDois();

  // Also observe for dynamically loaded content
  const observer = new MutationObserver((mutations) => {
    let hasNewNodes = false;
    for (const mutation of mutations) {
      if (mutation.addedNodes.length > 0) {
        hasNewNodes = true;
        break;
      }
    }
    if (hasNewNodes) {
      // Remove the processed flag so we can rescan
      document.body.removeAttribute(PROCESSED_ATTR);
      // Debounce
      clearTimeout(observer._timeout);
      observer._timeout = setTimeout(scanForDois, 500);
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

})();
