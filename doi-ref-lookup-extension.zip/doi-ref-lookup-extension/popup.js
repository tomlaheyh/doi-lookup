// popup.js — DOI-Ref-Lookup Extension popup

const SITE_URL = 'https://tomlaheyh.github.io/ref-lookup/';

const doiCount = document.getElementById('doiCount');
const doiList = document.getElementById('doiList');
const openBtn = document.getElementById('openBtn');
const clearBtn = document.getElementById('clearBtn');

function render(dois) {
  const count = dois.length;
  doiCount.textContent = count === 0 ? '' : `${count} DOI${count > 1 ? 's' : ''} collected`;
  doiList.textContent = dois.join(', ');
  openBtn.disabled = count === 0;
  clearBtn.disabled = count === 0;
}

// Load DOIs from background (reads from tab URL)
chrome.runtime.sendMessage({ action: 'getDois' }, (response) => {
  if (response && response.dois) {
    render(response.dois);
  } else {
    render([]);
  }
});

// Open all DOIs in ref-lookup
openBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'getDois' }, (response) => {
    const dois = (response && response.dois) || [];
    if (dois.length === 0) return;
    const url = `${SITE_URL}?doi=${encodeURIComponent(dois.join(','))}`;
    chrome.tabs.create({ url });
    window.close();
  });
});

// Clear all DOIs
clearBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'clearDois' });
  render([]);
});
