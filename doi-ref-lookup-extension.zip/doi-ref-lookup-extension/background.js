// background.js — DOI-Ref-Lookup Chrome Extension
// Validates DOIs, manages the ref-lookup tab
// The website tab's URL is the source of truth for accumulated DOIs

const SITE_URL = 'https://tomlaheyh.github.io/ref-lookup/';
let refLookupTabId = null;

// Listen for messages from content script and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'validateAndOpenDoi') {
    validateAndOpen(message.doi).then(sendResponse);
    return true;
  }
  if (message.action === 'getDois') {
    getCurrentDois().then(dois => sendResponse({ dois }));
    return true;
  }
  if (message.action === 'clearDois') {
    clearDois();
  }
});

// Validate DOI via handle API, then open if valid
async function validateAndOpen(doi) {
  try {
    const apiResponse = await fetch(`https://doi.org/api/handles/${encodeURIComponent(doi)}`);
    const data = await apiResponse.json();
    if (data.responseCode === 1) {
      await addDoiAndOpen(doi);
      return { valid: true };
    } else {
      return { valid: false };
    }
  } catch (e) {
    // If validation fails due to network, assume valid
    await addDoiAndOpen(doi);
    return { valid: true };
  }
}

// Get current DOIs from the existing ref-lookup tab's URL
async function getCurrentDois() {
  try {
    const tab = await findRefLookupTab();
    if (!tab || !tab.url) return [];
    const url = new URL(tab.url);
    const doiParam = url.searchParams.get('doi');
    if (!doiParam) return [];
    return decodeURIComponent(doiParam).split(',').filter(Boolean);
  } catch (e) {
    return [];
  }
}

// Find existing ref-lookup tab
async function findRefLookupTab() {
  // Check stored tab id first
  if (refLookupTabId !== null) {
    try {
      const tab = await chrome.tabs.get(refLookupTabId);
      if (tab && tab.url && tab.url.includes('tomlaheyh.github.io/ref-lookup')) {
        return tab;
      }
    } catch (e) {
      refLookupTabId = null;
    }
  }
  // Search for any ref-lookup tab
  const tabs = await chrome.tabs.query({ url: SITE_URL + '*' });
  if (tabs.length > 0) {
    refLookupTabId = tabs[0].id;
    return tabs[0];
  }
  return null;
}

async function addDoiAndOpen(doi) {
  // Get current DOIs from the existing tab
  const currentDois = await getCurrentDois();

  // Add new DOI if not already present
  if (!currentDois.includes(doi)) {
    currentDois.push(doi); // newest last — gets inserted at top via afterbegin
  }

  const url = `${SITE_URL}?doi=${encodeURIComponent(currentDois.join(','))}`;

  try {
    const existingTab = await findRefLookupTab();
    if (existingTab) {
      await chrome.tabs.update(existingTab.id, { url: url, active: true });
      await chrome.windows.update(existingTab.windowId, { focused: true });
      return;
    }

    // No existing tab — open new one
    const newTab = await chrome.tabs.create({ url: url });
    refLookupTabId = newTab.id;
  } catch (e) {
    const newTab = await chrome.tabs.create({ url: url });
    refLookupTabId = newTab.id;
  }

  updateBadge();
}

async function clearDois() {
  const existingTab = await findRefLookupTab();
  if (existingTab) {
    await chrome.tabs.update(existingTab.id, { url: SITE_URL, active: true });
  }
  refLookupTabId = null;
  updateBadge();
}

// Track when our tab is closed
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === refLookupTabId) {
    refLookupTabId = null;
    updateBadge();
  }
});

// Track URL changes on our tab (user removes DOIs on website)
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (tabId === refLookupTabId && changeInfo.url) {
    updateBadge();
  }
});

// Update badge with DOI count from the tab
async function updateBadge() {
  const dois = await getCurrentDois();
  const count = dois.length;
  chrome.action.setBadgeText({ text: count > 0 ? String(count) : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#005a8c' });
}

// Set initial badge
updateBadge();
